from controller import Robot
import pandas as pd

# --- Initialize Robot ---
robot = Robot()
timestep = int(robot.getBasicTimeStep())

# --- Load Excel file ---
excel_path = r"C:\Users\User\OneDrive\Desktop\project_library - Copy (2)\worlds\New folder\controllers\Book_search\Book_Library.xlsx"
try:
    df = pd.read_excel(excel_path)
except Exception as e:
    print("⚠️ Error loading Excel file:", e)
    exit()

# --- Function to search book ---
def search_book(book_name):
    result = df[df['Book Name'].str.lower() == book_name.lower()]
    if not result.empty:
        book_info = result.iloc[0]
        print(f"\n✅ Book '{book_info['Book Name']}' is available!")
        print(f"   Category: {book_info['Category']}")
        print(f"   Color: {book_info['Color']}")
        print(f"   Barcode: {book_info['Barcode']}")
        return True
    else:
        print(f"\n❌ Sorry, the book '{book_name}' is not available in the library.")
        return False

# --- Example: Search a book (replace with barcode detection later) ---
book_to_search = "dune"  # For now, hardcoded
found = search_book(book_to_search)

# --- Main simulation loop ---
while robot.step(timestep) != -1:
    # Here you can add code to move Tiago or interact
    # Example: if a barcode is detected, call search_book(barcode)
    pass
